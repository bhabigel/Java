import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Manager class to handle shapes.
 */
public class ShapesManager {

    /**
     * Reads shapes from the specified file and returns a list of shapes.
     * @param fileName the name of the file to read
     * @return list of shapes
     * @throws FileNotFoundException if the file is not found
     * @throws InvalidFormatException if the data in the file is not in the correct format
     * @throws IllegalArgumentException if an invalid shape type is encountered or if values are invalid
     */
    public static List<Shapes> readShapesFromFile(String fileName)
            throws FileNotFoundException, InvalidFormatException {
        List<Shapes> shapes = new ArrayList<>();

        File file = new File(fileName);
        Scanner sc = new Scanner(file);

        if (!sc.hasNextLine()) {
            throw new NoSuchElementException("The file is empty.");
        }

        int shapeCount = Integer.parseInt(sc.nextLine().trim());

        for (int i = 0; i < shapeCount; i++) {
            if (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                String[] parts = line.split(" ");

                if (parts.length < 4) {
                    throw new InvalidFormatException("Invalid format on line " + (i + 2));
                }

                String type = parts[0];

                double centerX;
                double centerY;
                double size;

                try {
                    centerX = Double.parseDouble(parts[1]);
                    centerY = Double.parseDouble(parts[2]);
                    size = Double.parseDouble(parts[3]);
                } catch (NumberFormatException e) {
                    throw new InvalidFormatException("Invalid number format on line " + (i + 2) + ": " + e.getMessage());
                }

                if (size < 0) {
                    throw new IllegalArgumentException("Size cannot be negative on line " + (i + 2));
                }

                switch (type.toLowerCase()) {
                    case "c":
                        shapes.add(new Circle(centerX, centerY, size));
                        break;
                    case "t":
                        shapes.add(new Triangle(centerX, centerY, size));
                        break;
                    case "s":
                        shapes.add(new Square(centerX, centerY, size));
                        break;
                    case "h":
                        shapes.add(new Hexagon(centerX, centerY, size));
                        break;
                    default:
                        throw new IllegalArgumentException("Invalid shape type: " + type + " on line " + (i + 2));
                }
            } else {
                throw new InvalidFormatException("Invalid format on line " + (i + 2));
            }
        }
        sc.close();
        return shapes;
    }

    /**
     * Finds the shape with the smallest difference between area and perimeter.
     * @param shapes List of shapes
     * @return The shape with the smallest difference
     */
    public static Shapes findShapeWithSmallestDifference(List<Shapes> shapes) {
        double[] minDifferenceHolder = {Double.MAX_VALUE};
        Shapes[] closestShapeHolder = {null};

        shapes.forEach(shape -> {
            double difference = shape.getDifference();
            if (difference < minDifferenceHolder[0]) {
                minDifferenceHolder[0] = difference;
                closestShapeHolder[0] = shape;
            }
        });

        return closestShapeHolder[0];
    }
}
