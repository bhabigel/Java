/**
 * Class representing a square shape.
 */
public class Square extends Shapes {
    private double side;

    /**
     * Constructs a square with the given center coordinates and side length.
     * @param pointx X-coordinate of the square's center
     * @param pointy Y-coordinate of the square's center
     * @param side Length of the square's side
     * @throws IllegalArgumentException if the side length is less than or equal to zero
     */
    public Square(double pointx, double pointy, double side) {
        super(pointx, pointy);
        if (side <= 0) {
            throw new IllegalArgumentException("Side length must be greater than zero.");
        }
        this.side = side;
    }

    /**
     * Calculates the perimeter of the square.
     * @return the perimeter of the square
     */
    public double getPerimeter() {
        return 4 * side;
    }

    /**
     * Calculates the area of the square.
     * @return the area of the square
     */
    public double getArea() {
        return side * side;
    }
}
