/**
 * Class representing a triangle shape.
 */
public class Triangle extends Shapes {
    private double side;
    /**
     * Constructs a triangle with the given center coordinates and side length.
     * @param pointx X-coordinate of the triangle's center
     * @param pointy Y-coordinate of the triangle's center
     * @param side Length of the triangle's side
     * @throws IllegalArgumentException if the side length is less than or equal to zero
     */
    public Triangle(double pointx, double pointy, double side) {
        super(pointx, pointy);
        if (side <= 0) {
            throw new IllegalArgumentException("Side length must be greater than zero."); // Validate side length
        }
        this.side = side;
    }

    /**
     * Calculates the perimeter of the triangle.
     * @return the perimeter of the triangle
     */
    public double getPerimeter() {
        return side * 3;
    }

    /**
     * Calculates the area of the triangle using the formula (base * height) / 2.
     * @return the area of the triangle
     */
    public double getArea() {
        double height = side * Math.sqrt(3) / 2;
        return side * height / 2;
    }
}
