/**
 * Class representing a circle shape.
 */
public class Circle extends Shapes {
    private double radius;

    /**
     * Constructs a circle with the given center coordinates and radius.
     * @param pointx X-coordinate of the circle's center
     * @param pointy Y-coordinate of the circle's center
     * @param radius Radius of the circle
     * @throws IllegalArgumentException if the radius is non-positive
     */
    public Circle(double pointx, double pointy, double radius) {
        super(pointx, pointy);
        if (radius <= 0) {
            throw new IllegalArgumentException("Radius must be positive.");
        }
        this.radius = radius;
    }

    /**
     * Calculates the perimeter (circumference) of the circle.
     * @return perimeter of the circle
     */
    public double getPerimeter() {
        return 2 * radius * Math.PI;
    }

    /**
     * Calculates the area of the circle.
     * @return area of the circle
     */
    public double getArea() {
        return radius * radius * Math.PI;
    }
}
