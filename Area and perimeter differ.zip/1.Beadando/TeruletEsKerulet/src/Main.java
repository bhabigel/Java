import java.io.FileNotFoundException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * @author Barabás Hanga-Abigél
 */
public class Main {
    /**
     * Main method of the program.
     * This method prompts the user for a file name,
     * reads shapes from the specified file, and
     * calculates and prints the shape with the smallest
     * difference between area and perimeter.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        List<Shapes> shapes = null;
        Scanner inputScanner = new Scanner(System.in);

        System.out.print("Enter the name of the input file: ");
        String fileName = inputScanner.nextLine();

        try {
            shapes = ShapesManager.readShapesFromFile(fileName);
        } catch (FileNotFoundException e) {
            System.err.println("Error: The file '" + fileName + "' was not found. Please check the file path and name.");
            return;
        } catch (InvalidFormatException e) {
            System.err.println("Error: " + e.getMessage() + " Please ensure the file contents are correctly formatted.");
            return;
        } catch (IllegalArgumentException e) {
            System.err.println("Error: " + e.getMessage() + " Ensure that all shape types and values are valid.");
            return;
        } catch (NoSuchElementException e) {
            System.err.println("Error: The input file is empty or has incomplete data. Please provide a valid file.");
            return;
        }

        Shapes closestShape = ShapesManager.findShapeWithSmallestDifference(shapes);
        if (closestShape != null) {
            System.out.printf("%s (Area: %.2f, perimeter: %.2f, difference: %.2f)\n",
                    closestShape.getClass().getSimpleName(),
                    closestShape.getArea(),
                    closestShape.getPerimeter(),
                    closestShape.getDifference());
        }
    }
}
