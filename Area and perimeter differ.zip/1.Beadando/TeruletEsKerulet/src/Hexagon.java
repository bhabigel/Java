/**
 * Class representing a hexagon shape.
 */
public class Hexagon extends Shapes {
    private double side;

    /**
     * Constructs a hexagon with the given center coordinates and side length.
     * @param pointx X-coordinate of the hexagon's center
     * @param pointy Y-coordinate of the hexagon's center
     * @param side Length of one side of the hexagon
     * @throws IllegalArgumentException if the side length is non-positive
     */
    public Hexagon(double pointx, double pointy, double side) {
        super(pointx, pointy);
        if (side <= 0) {
            throw new IllegalArgumentException("Side length must be positive.");
        }
        this.side = side;
    }

    /**
     * Calculates the area of the hexagon.
     * @return area of the hexagon
     */
    public double getArea() {
        return (3 * Math.sqrt(3) / 2) * side * side;
    }

    /**
     * Calculates the perimeter of the hexagon.
     * @return perimeter of the hexagon
     */
    public double getPerimeter() {
        return 6 * side;
    }
}
