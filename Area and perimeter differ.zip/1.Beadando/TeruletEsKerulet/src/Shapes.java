import java.util.List;

/**
 * Abstract base class for all shapes.
 */
public abstract class Shapes {
    protected double pointx;
    protected double pointy;
    /**
     * Constructs a shape with the given center coordinates.
     *
     * @param x X-coordinate of the shape's center
     * @param y Y-coordinate of the shape's center
     */
    public Shapes(double x, double y) {
        this.pointx = x;
        this.pointy = y;
    }

    /**
     * Abstract method to calculate the perimeter of the shape.
     *
     * @return the perimeter of the shape
     */
    public abstract double getPerimeter();

    /**
     * Abstract method to calculate the area of the shape.
     *
     * @return the area of the shape
     */
    public abstract double getArea();

    /**
     * Calculates the absolute difference between the area and perimeter of the shape.
     *
     * @return the absolute difference
     */
    public double getDifference() {
        return Math.abs(getArea() - getPerimeter());
    }
}
