import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        int size = 0;
        while (true) {
            String input = JOptionPane.showInputDialog("Válassz egy táblaméretet (5, 7, 9): ");
            if (input == null) {
                System.exit(0);
            }
            try {
                size = Integer.parseInt(input);
                if (size == 5 || size == 7 || size == 9) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Helytelen táblaméret! Kérlek válassz újra.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Helytelen táblaméret! Kérlek válassz újra.");
            }
        }

        /**
         * Initializes the GameModel with the specified board size.
         * @param size the size of the game board (5, 7, or 9)
         */
        GameModel gameModel = new GameModel(size);

        /**
         * Initializes the GameGUI with the game model to display the board.
         * @param gameModel the model representing the game state
         */
        GameGUI gameGUI = new GameGUI(gameModel);

        /**
         * Initializes the GameController with the game model and GUI.
         * @param gameModel the model representing the game state
         * @param gameGUI the GUI interface for the game
         */
        GameController gameController = new GameController(gameModel, gameGUI);
    }
}
