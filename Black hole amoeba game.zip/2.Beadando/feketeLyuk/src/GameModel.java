import java.util.ArrayList;
import java.util.List;

public class GameModel {
    private int size;
    private Spaceship[][] board;
    private List<Spaceship> player1Ships;
    private List<Spaceship> player2Ships;
    private int blackHoleRow;
    private int blackHoleCol;
    private Player currentPlayer;

    /**
     * Initializes the game model with a board of the specified size and sets up the initial game state.
     * @param size the size of the game board
     */
    public GameModel(int size) {
        this.size = size;
        this.board = new Spaceship[size][size];
        this.player1Ships = new ArrayList<>();
        this.player2Ships = new ArrayList<>();
        this.blackHoleRow = size / 2;
        this.blackHoleCol = size / 2;
        this.currentPlayer = Player.PLAYER_1;
        setupBoard();
    }

    /**
     * Sets up the board with initial positions for each player's spaceships.
     */
    private void setupBoard() {
        for (int i = 0; i < size / 2; i++) {
            player1Ships.add(new Spaceship(Player.PLAYER_1, i, i));
            player2Ships.add(new Spaceship(Player.PLAYER_2, size - 1 - i, size - 1 - i));
            board[i][i] = player1Ships.get(i);
            board[size - 1 - i][size - 1 - i] = player2Ships.get(i);
        }
    }

    /**
     * Gets the size of the game board.
     * @return the size of the board
     */
    public int getSize() {
        return size;
    }

    /**
     * Gets the current state of the game board.
     * @return a 2D array representing the board with spaceships
     */
    public Spaceship[][] getBoard() {
        return board;
    }

    /**
     * Gets the current player.
     * @return the current player
     */
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    /**
     * Switches to the other player.
     */
    public void switchPlayer() {
        currentPlayer = currentPlayer.switchPlayer();
    }

    /**
     * Moves a spaceship in a specified direction.
     * @param player the player who is moving the spaceship
     * @param fromRow the starting row of the spaceship
     * @param fromCol the starting column of the spaceship
     * @param direction the direction to move ("up", "down", "left", "right")
     */
    public void moveSpaceship(Player player, int fromRow, int fromCol, String direction) {
        Spaceship ship = board[fromRow][fromCol];
        if (ship != null && ship.getPlayer() == player) {
            int newRow = fromRow;
            int newCol = fromCol;

            switch (direction) {
                case "up":
                    while (newRow > 0) {
                        if (newRow - 1 == blackHoleRow && newCol == blackHoleCol) {
                            ship.deactivate();
                            board[fromRow][fromCol] = null;
                            checkWin();
                            return;
                        }
                        if (board[newRow - 1][newCol] != null) {
                            break;
                        }
                        newRow--;
                    }
                    break;
                case "down":
                    while (newRow < size - 1) {
                        if (newRow + 1 == blackHoleRow && newCol == blackHoleCol) {
                            ship.deactivate();
                            board[fromRow][fromCol] = null;
                            checkWin();
                            return;
                        }
                        if (board[newRow + 1][newCol] != null) {
                            break;
                        }
                        newRow++;
                    }
                    break;
                case "left":
                    while (newCol > 0) {
                        if (newRow == blackHoleRow && newCol - 1 == blackHoleCol) {
                            ship.deactivate();
                            board[fromRow][fromCol] = null;
                            checkWin();
                            return;
                        }
                        if (board[newRow][newCol - 1] != null) {
                            break;
                        }
                        newCol--;
                    }
                    break;
                case "right":
                    while (newCol < size - 1) {
                        if (newRow == blackHoleRow && newCol + 1 == blackHoleCol) {
                            ship.deactivate();
                            board[fromRow][fromCol] = null;
                            checkWin();
                            return;
                        }
                        if (board[newRow][newCol + 1] != null) {
                            break;
                        }
                        newCol++;
                    }
                    break;
            }

            if (board[newRow][newCol] == null) {
                board[fromRow][fromCol] = null;
                ship.setPosition(newRow, newCol);
                board[newRow][newCol] = ship;
            }
        }
    }

    /**
     * Checks if any player has won the game.
     * @return true if a player has won; false otherwise
     */
    public boolean checkWin() {
        int player1Count = 0;
        int player2Count = 0;

        for (Spaceship ship : player1Ships) {
            if (!ship.isActive()) {
                player1Count++;
            }
        }

        for (Spaceship ship : player2Ships) {
            if (!ship.isActive()) {
                player2Count++;
            }
        }

        if (player1Count >= player1Ships.size() || player2Count >= player2Ships.size()) {
            if (player1Count >= player1Ships.size()) {
                System.out.println("Player 1 wins!");
            } else {
                System.out.println("Player 2 wins!");
            }
            return true;
        }

        return false;
    }

    /**
     * Gets the row position of the black hole.
     * @return the row index of the black hole
     */
    public int getBlackHoleRow() {
        return blackHoleRow;
    }

    /**
     * Gets the column position of the black hole.
     * @return the column index of the black hole
     */
    public int getBlackHoleCol() {
        return blackHoleCol;
    }
}
