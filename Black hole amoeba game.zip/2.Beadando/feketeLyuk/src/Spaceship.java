public class Spaceship {
    private Player player;
    private int[] position;
    private boolean active;

    /**
     * Constructs a Spaceship for the specified player at the given position.
     * @param player the player who controls this spaceship
     * @param row the initial row position of the spaceship
     * @param col the initial column position of the spaceship
     */
    public Spaceship(Player player, int row, int col) {
        this.player = player;
        this.position = new int[]{row, col};
        this.active = true;
    }

    /**
     * Gets the player controlling this spaceship.
     * @return the player associated with this spaceship
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * Gets the current position of the spaceship.
     * @return an array containing the row and column of the spaceship
     */
    public int[] getPosition() {
        return position;
    }

    /**
     * Sets the position of the spaceship.
     * @param row the new row position of the spaceship
     * @param col the new column position of the spaceship
     */
    public void setPosition(int row, int col) {
        this.position[0] = row;
        this.position[1] = col;
    }

    /**
     * Checks if the spaceship is active.
     * @return true if the spaceship is active, false otherwise
     */
    public boolean isActive() {
        return active;
    }

    /**
     * Deactivates the spaceship, setting it as inactive.
     */
    public void deactivate() {
        this.active = false;
    }

    /**
     * Sets the active status of the spaceship.
     * @param active the new active status of the spaceship
     */
    public void setActive(boolean active) {
        this.active = active;
    }
}
