import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameGUI extends JFrame {
    private GameModel gameModel;
    private JButton[][] buttons;
    private JLabel currentPlayerLabel;

    /**
     * Initializes the game GUI with a reference to the game model.
     * @param model the game model that represents the game state
     */
    public GameGUI(GameModel model) {
        this.gameModel = model;
        this.buttons = new JButton[model.getSize()][model.getSize()];
        setupGUI();
    }

    /**
     * Sets up the graphical user interface, including the board and the current player label.
     */
    private void setupGUI() {
        setTitle("Fekete Lyuk Játék");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        currentPlayerLabel = new JLabel("Soron lévő játékos: " +
                (gameModel.getCurrentPlayer() == Player.PLAYER_1 ? "Játékos 1: Kék" : "Játékos 2: Piros"));
        add(currentPlayerLabel, BorderLayout.NORTH);

        JPanel boardPanel = new JPanel(new GridLayout(gameModel.getSize(), gameModel.getSize()));
        for (int i = 0; i < gameModel.getSize(); i++) {
            for (int j = 0; j < gameModel.getSize(); j++) {
                buttons[i][j] = new JButton();
                buttons[i][j].setBackground(Color.LIGHT_GRAY);
                final int row = i;
                final int col = j;

                buttons[i][j].addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (gameModel.getBoard()[row][col] != null &&
                                gameModel.getBoard()[row][col].getPlayer() == gameModel.getCurrentPlayer()) {

                            String direction;
                            do {
                                direction = JOptionPane.showInputDialog("Milyen irányba szeretnéd mozgatni? (up, down, left, right)");
                                if (direction == null) {
                                    return;
                                }
                                if (!direction.equals("up") && !direction.equals("down") &&
                                        !direction.equals("left") && !direction.equals("right")) {
                                    JOptionPane.showMessageDialog(null, "Helytelen irány! Kérlek, írd be újra.");
                                }
                            } while (!direction.equals("up") && !direction.equals("down") &&
                                    !direction.equals("left") && !direction.equals("right"));

                            gameModel.moveSpaceship(gameModel.getCurrentPlayer(), row, col, direction);
                            updateBoard();

                            if (gameModel.checkWin()) {
                                int response = JOptionPane.showConfirmDialog(null,
                                        "A játék véget ért! Játékos " +
                                                (gameModel.getCurrentPlayer() == Player.PLAYER_1 ? "1" : "2") + " nyert! Biztosan kilépsz?",
                                        "Kilépés megerősítése",
                                        JOptionPane.YES_NO_OPTION);
                                if (response == JOptionPane.YES_OPTION) {
                                    System.exit(0);
                                } else {
                                    resetGame();
                                }
                            } else {
                                gameModel.switchPlayer();
                                currentPlayerLabel.setText("Soron lévő játékos: " +
                                        (gameModel.getCurrentPlayer() == Player.PLAYER_1 ? "Játékos 1: Kék" : "Játékos 2: Piros"));
                            }

                        } else {
                            JOptionPane.showMessageDialog(null, "Ez nem a te hajód vagy a hajód nem mozgatható!");
                        }
                    }
                });
                boardPanel.add(buttons[i][j]);
            }
        }
        add(boardPanel, BorderLayout.CENTER);
        updateBoard();
        setVisible(true);
    }

    /**
     * Updates the board's graphical display based on the game model's current state.
     */
    private void updateBoard() {
        Spaceship[][] board = gameModel.getBoard();
        for (int i = 0; i < gameModel.getSize(); i++) {
            for (int j = 0; j < gameModel.getSize(); j++) {
                buttons[i][j].setText("");
                buttons[i][j].setBackground(Color.LIGHT_GRAY);
                if (board[i][j] != null) {
                    if (board[i][j].getPlayer() == Player.PLAYER_1) {
                        buttons[i][j].setBackground(Color.BLUE);
                    } else {
                        buttons[i][j].setBackground(Color.RED);
                    }
                }
            }
        }
        buttons[gameModel.getBlackHoleRow()][gameModel.getBlackHoleCol()].setBackground(Color.BLACK);
    }

    /**
     * Resets the game by reinitializing the game model and updating the board display.
     */
    private void resetGame() {
        gameModel = new GameModel(gameModel.getSize());
        updateBoard();
    }
}
