public class GameController {
    private GameModel gameModel;

    private GameGUI gameGUI;

    /**
     * Constructor for GameController.
     *
     * @param model the GameModel instance that contains the game logic and data
     * @param gui the GameGUI instance that provides the user interface
     */
    public GameController(GameModel model, GameGUI gui) {
        this.gameModel = model;
        this.gameGUI = gui;
    }
}
