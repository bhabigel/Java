import java.awt.Color;

public enum Player {
    PLAYER_1("Player 1", Color.BLUE),
    PLAYER_2("Player 2", Color.RED);

    private final String name;
    private final Color color;

    /**
     * Constructs a Player with the specified name and color.
     * @param name the name of the player
     * @param color the color associated with the player
     */
    Player(String name, Color color) {
        this.name = name;
        this.color = color;
    }

    /**
     * Gets the name of the player.
     * @return the name of the player
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the color associated with the player.
     * @return the color of the player
     */
    public Color getColor() {
        return color;
    }

    /**
     * Switches to the other player.
     * @return PLAYER_2 if the current player is PLAYER_1; otherwise, PLAYER_1
     */
    public Player switchPlayer() {
        return this == PLAYER_1 ? PLAYER_2 : PLAYER_1;
    }
}
